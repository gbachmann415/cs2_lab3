/*
Gunnar Bachmann
2/4/2020
DYI.java
CS2
 */

package rit.stu;

import rit.cs.*;

import java.util.*;

public class DYI {
    /*
    main method
    prints that the DYI is open
    creates instance of DYI - dyiInstance
    calls the mainloop
     */
    public static void main(String[] args) {
        System.out.println("Derp Your Interpreter v1.0");

        DYI dyiInstance = new DYI();

        dyiInstance.mainLoop();
    }


    /*
    mainLoop
    until the user enters "quit", it will continue to ask
    the user to input a prefix expression.
    It then pass it to parse after making the list of the prefix expression.
    Once parse is done, it will then output the emit and evaluate.
     */
    private void mainLoop() {
        while (true) {
            Scanner in = new Scanner(System.in);
            System.out.print(">");
            String x = in.nextLine();
            if (x.equals("quit")) {
                System.out.println("Goodbye! :(");
                return;
            }
            String[] y = x.split(" ");
            List<String> z = new ArrayList<String>(Arrays.asList(y));
            Expression returnedExpression = parse(z);
            System.out.println("emit: " + returnedExpression.emit());
            System.out.println("evaluate: " + returnedExpression.evaluate());
        }
    }

    /*
    parse method

    decides which is the right class to use depending on
    whether it is +, -, /, etc...
     */
    public Expression parse(List<String> tokens) {
        String obj = tokens.remove(0);
        if (obj.equals("+")) {
            Expression left = parse(tokens);
            Expression right = parse(tokens);
            return new AddExpression(left, right);
        } else if (obj.equals("/")) {
            Expression left = parse(tokens);
            Expression right = parse(tokens);
            return new DivExpression(left, right);
        } else if (obj.equals("%")) {
            Expression left = parse(tokens);
            Expression right = parse(tokens);
            return new ModExpression(left, right);
        } else if (obj.equals("*")) {
            Expression left = parse(tokens);
            Expression right = parse(tokens);
            return new MulExpression(left, right);
        } else if (obj.equals("-")) {
            Expression left = parse(tokens);
            Expression right = parse(tokens);
            return new SubExpression(left, right);
        } else {
            return new IntExpression(Integer.parseInt(obj));
        }
    }
}