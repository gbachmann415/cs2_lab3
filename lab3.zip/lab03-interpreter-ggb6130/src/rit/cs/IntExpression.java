package rit.cs;

public class IntExpression implements Expression{
    private int val;

    public IntExpression(int nValue) {
        this.val = nValue;
    }

    @Override
    public int evaluate(){
        return this.val;
    }

    @Override
    public String emit() {
        return Integer.toString(this.val);
    }
}
